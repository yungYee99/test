export function getSelectBannedArea(model) {
  const { isGamingBanned, isFBBanned, isHotelBanned } = model;
  const barredArea = {
    isGamingBanned: 'isGamingBanned',
    isFBBanned: 'isFBBanned',
    isHotelBanned: 'isHotelBanned'
  };
  const bannedAreaList = [];

  if (isGamingBanned && isFBBanned && isHotelBanned) {
    bannedAreaList.push('all');
    return bannedAreaList;
  }

  Object.keys(barredArea).filter(item => model[item]).map(item => bannedAreaList.push(item));

  return bannedAreaList;
}

export function getBannedAreaOptionList() {
  return [
    { value: 'all', label: 'All' },
    { value: 'isFBBanned', label: 'F&B' },
    { value: 'isHotelBanned', label: 'Hotel' },
    { value: 'isGamingBanned', label: 'Gaming' }
  ];
}
