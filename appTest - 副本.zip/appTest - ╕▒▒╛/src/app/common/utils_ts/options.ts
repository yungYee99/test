export const genderOptions = [
  { code: 'MALE', name: 'player.labelGenderMale' },
  { code: 'FEMALE', name: 'player.labelGenderFemale' }
];

export function getGenderName(code) {
  const result = genderOptions.find(item => item.code === code);
  return result ? result.name : '';
}
