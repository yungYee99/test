export function formatRestrictionDescription(description) {
  return description === '' ? '' : ', ';
}