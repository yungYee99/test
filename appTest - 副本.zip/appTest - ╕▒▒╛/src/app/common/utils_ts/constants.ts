export default {
  bannedLogDefaultPhotoUrl: '/api/v1/bannedLogs/photo/',
  playerPhotoUrl: '/api/v1/players/photo/',
};
