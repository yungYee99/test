import * as Moment from 'moment';

// The parameter specifyMomentFormat is used to solve the ie problem with format 'DD-MMM-YYYY'
export function formatDate(date, format = 'DD-MMM-YYYY hh:mm A', specifyMomentFormat = false, specifiedFormat = 'DD-MMM-YYYY hh:mm A') {
  if (date) {
    return specifyMomentFormat ? Moment(date, specifiedFormat).format(format) : Moment(date).format(format);
  }

  return '';
}

export function formatTime(time) {
  if (time.indexOf('AM') > 0) {
    return time.replace('AM', ' AM');
  } else {
    return time.replace('PM', ' PM');
  }
}

export function toFrontEndBirthday(date, specifyMomentFormat = false) {
  return formatDate(date, 'DD-MMM-YYYY', specifyMomentFormat);
}

export function toFrontEndDate(date, specifyMomentFormat = false) {
  return formatDate(date, 'DD-MMM-YYYY', specifyMomentFormat);
}

export function toFrontEndTime(date, specifyMomentFormat = false) {
  return formatDate(date, 'hh:mm A', specifyMomentFormat);
}

export function toBackEndDate(date) {
  return formatDate(date, 'YYYY-MM-DD HH:mm:ss', true);
}

export function getMdbDateComponentDisplayLabel(date) {
  date = date ? Moment(date, 'DD-MMM-YYYY hh:mm A') : Moment();

  return {
    year: date.get('years'),
    month: date.get('months') + 1,
    day: date.get('date')
  };
}

export function getMdbTimeComponentDisplayLabel(time) {
  if (!time) {
    return { 'h': '05', 'm': '00', 'ampm': 'AM' };
  }

  time = time.split(':');
  const index = time[1].indexOf('M') - 1;

  return {
    'h': time[0],
    'm': time[1].substring(0, index),
    'ampm': time[1].substring(index)
  };
}
