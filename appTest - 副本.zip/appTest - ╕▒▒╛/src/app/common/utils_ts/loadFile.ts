export function downloadFile(blob, filename) {
  // ie
  if (navigator.appVersion.toString().indexOf('.NET') > 0 ||
    navigator.appVersion.toString().indexOf('Edge') > 0) {
    window.navigator.msSaveBlob(blob, filename);
  } else {
    const link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
  }
}
