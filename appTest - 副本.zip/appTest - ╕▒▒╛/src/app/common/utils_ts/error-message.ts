// Common System Error
export const INVALID_PARAMS = 900001;
export const OBJECT_NOT_FOUND = 900002;
export const INVALID_OPERATION = 900003;
export const REQUEST_TRANSFORM_FAILED = 900004;
export const REQUEST_FAILED = 900005;
export const UNHANDLED_SYSTEM_EXCEPTION = 999999;

// Security
export const INVALID_DIRECTORYSERVICE_INVALID_EMPLOYEE = 101001;
export const INVALID_DIRECTORYSERVICE_INVALID_PASSWORD = 101002;
export const INVALID_DIRECTORYSERVICE_ACCOUNT_LOCKED = 101003;
export const INVALID_DIRECTORYSERVICE_PASSWORD_EXPIRED = 101004;
export const INVALID_DIRECTORYSERVICE_ACCOUNT_DISABLED = 101005;
export const INVALID_DIRECTORYSERVICE_ACCESS = 101006;
export const INVALID_DIRECTORYSERVICE_QUERY_FAILED = 101007;
export const EXPIRED_TOKEN = 101008;
export const INVALID_TOKEN = 101009;
export const NO_PERMISSION_TO_LOGIN = 101010;

// BannedLog Player
export const GCM_PLAYER_ALREADY_LINKED_TO_FLAGGED_PLAYER = 102001;
export const DUPLICATED_PLAYER_INFO = 102002;
export const GCM_PLAYER_CANNOT_BE_UNLINKED = 102004;
export const WYNN_ID_INVALID = 102005;
export const GCM_PLAYER_CANNOT_BE_RELINKED = 102006;

export const CANNOT_OPERATE_DELETED_OR_HISTORY_BANNED_PLAYER = 102003;
export const CANNOT_OPERATE_DELETED_OR_HISTORY_FLAGGED_PLAYER = 102007;
export const GCM_PLAYER_ALREADY_LINKED_TO_BARRED_PLAYER = 102008;

// Alert
export const STATUS_CHECK_FAILED = 103001;
export const CANNOT_LOCK_MULTIPLE_ALERTS = 103002;
export const CANNOT_UNLOCK_OTHER_USER_ALERT = 103003;
export const CANNOT_ACK_OTHER_USER_ALERT = 103004;
export const ALERT_ALREADY_LINKED_TO_FLAGGED_PLAYER = 103005;
export const ALERT_ALREADY_LINKED_TO_BARRED_PLAYER = 103006;
export const ALERT_CANNOT_CHANGE_FLAGGED_PLAYER_LINKED_GCM_PLAYER = 103007;
export const ALERT_CANNOT_CHANGE_BARRED_PLAYER_LINKED_GCM_PLAYER = 103008;

// Setting
export const DUPLICATED_WITH_EXISTED_REASON = 104001;

// Upload BannedList
export const UNEXPECTED_UPLOAD_ERROR = 105000;
export const INCORRECT_FILE_FORMAT = 105001;
export const MISSING_REQUIRE_DATA = 105002;
export const INCORRECT_CELL_FORMAT = 105003;
export const INVALID_CELL_VALUE = 105004;
export const END_DATE_CANNOT_BE_EARLIER_THAN_CURRENT_DATE = 105005;
export const END_DATE_CANNOT_BE_EARLIER_THAN_START_DATE = 105006;
export const INVALID_WYNNID = 105007;
export const DUPLICATE_WYNNID_IN_ONE_FILE = 105008;
export const DUPLICATE_PLAYER_INFO_IN_ONE_FILE = 105009;
export const WYNNID_DUPLICATE_WITH_EXISTING_BARRED_PLAYER = 105010;
export const WYNNID_DUPLICATE_WITH_EXISTING_FLAGGED_PLAYER = 105011;
export const DUPLICATE_DETAIL_INFO_IN_BANNED_PLAYER = 105012;

// Upload BannedPhotos
export const UPLOADED_PHOTO_FILE_CANNOT_MATCH_BARRED_PLAYER = 105013;
export const UPLOADED_PHOTO_FILE_MATCH_MULTIPLE_BARRED_PLAYER = 105014;
export const UPLOADED_PHOTO_FILE_CANNOT_MATCH_FLAGGED_PLAYER = 105015;
export const UPLOADED_PHOTO_FILE_MATCH_MULTIPLE_FLAGGED_PLAYER = 105016;
export const NO_RESTRICTION_IN_PROPERTY_AND_AREA = 105017;
export const WRONG_PHOTO_FORMAT = 105018;

export const ErrorMessage = {
  [UNHANDLED_SYSTEM_EXCEPTION]: { title: 'message.systemErrorTitle', message: 'message.systemError' },
  [INVALID_PARAMS]: { title: 'message.dataError', message: 'message.invalidParameters' },
  [GCM_PLAYER_ALREADY_LINKED_TO_FLAGGED_PLAYER]: 'message.playerAlreadyLinkedToFlaggedPlayer',
  [GCM_PLAYER_ALREADY_LINKED_TO_BARRED_PLAYER]: 'message.playerAlreadyLinkedToBarredPlayer',
  [NO_RESTRICTION_IN_PROPERTY_AND_AREA]: 'message.noRestrictionInPropertyAndArea',
  [CANNOT_OPERATE_DELETED_OR_HISTORY_BANNED_PLAYER]: {
    title: 'message.operateDeletedBannedErrorTitle', message: 'message.operateDeletedBarredError'
  },
  [CANNOT_OPERATE_DELETED_OR_HISTORY_FLAGGED_PLAYER]: {
    title: 'message.operateDeletedBannedErrorTitle', message: 'message.operateDeletedFlaggedError'
  },
  [GCM_PLAYER_CANNOT_BE_UNLINKED]: { title: 'message.unlinkDirectlyLinkedErrorTitle', message: 'message.unlinkDirectlyLinkedErrorMessage' },
  [GCM_PLAYER_CANNOT_BE_RELINKED]: { title: 'message.linkDirectlyLinkedErrorTitle', message: 'message.linkDirectlyLinkedErrorMessage' },
  [WYNN_ID_INVALID]: 'message.invalid',
  [DUPLICATED_PLAYER_INFO]: 'message.duplicatedPlayerInfo',
  [INVALID_DIRECTORYSERVICE_INVALID_PASSWORD]: 'message.loginInvalidParams',
  [INVALID_DIRECTORYSERVICE_PASSWORD_EXPIRED]: 'message.loginInvalidParams',
  [INVALID_DIRECTORYSERVICE_ACCOUNT_DISABLED]: 'message.loginNoPermission',
  [NO_PERMISSION_TO_LOGIN]: 'message.loginNoPermission',
  [INVALID_DIRECTORYSERVICE_ACCOUNT_LOCKED]: 'message.loginLocked',
  [INVALID_DIRECTORYSERVICE_INVALID_EMPLOYEE]: 'message.loginInvalidEmployee',
  [DUPLICATED_WITH_EXISTED_REASON]: 'setting.barredReasonDuplicatedMessage',
  [UNEXPECTED_UPLOAD_ERROR]: 'message.unexpectedUploadError',
  [INCORRECT_FILE_FORMAT]: 'message.incorrectFileFormat',
  [MISSING_REQUIRE_DATA]: 'message.missingRequireData',
  [INCORRECT_CELL_FORMAT]: 'message.incorrectCellFormat',
  [INVALID_CELL_VALUE]: 'message.invalidCellValue',
  [END_DATE_CANNOT_BE_EARLIER_THAN_CURRENT_DATE]: 'message.endDateCannotBeEarlierThanCurrentDate',
  [END_DATE_CANNOT_BE_EARLIER_THAN_START_DATE]: 'message.endDateCannotBeEarlierThanStartDate',
  [INVALID_WYNNID]: 'message.invalidWynnId',
  [DUPLICATE_WYNNID_IN_ONE_FILE]: 'message.duplicateWynnIdInOneFile',
  [DUPLICATE_PLAYER_INFO_IN_ONE_FILE]: 'message.duplicatePlayerInfoInOneFile',
  [WYNNID_DUPLICATE_WITH_EXISTING_BARRED_PLAYER]: 'message.wynnIdDuplicateWithExistingBarredPlayer',
  [WYNNID_DUPLICATE_WITH_EXISTING_FLAGGED_PLAYER]: 'message.wynnIdDuplicateWithExistingFlaggedPlayer',
  [DUPLICATE_DETAIL_INFO_IN_BANNED_PLAYER]: 'message.duplicateDetailInfoInBannedPlayer',
  [UPLOADED_PHOTO_FILE_CANNOT_MATCH_BARRED_PLAYER]: 'message.uploadedPhotoFileCannotMatchBarredPlayer',
  [UPLOADED_PHOTO_FILE_MATCH_MULTIPLE_BARRED_PLAYER]: 'message.uploadedPhotoFileMatchMultipleBarredPlayer',
  [UPLOADED_PHOTO_FILE_CANNOT_MATCH_FLAGGED_PLAYER]: 'message.uploadedPhotoFileCannotMatchFlaggedPlayer',
  [UPLOADED_PHOTO_FILE_MATCH_MULTIPLE_FLAGGED_PLAYER]: 'message.uploadedPhotoFileMatchMultipleFlaggedPlayer',
  [WRONG_PHOTO_FORMAT]: 'message.wrongPhotoFormat',
  [ALERT_ALREADY_LINKED_TO_FLAGGED_PLAYER]: 'message.playerAlreadyLinkedToFlaggedPlayer',
  [ALERT_ALREADY_LINKED_TO_BARRED_PLAYER]: 'message.playerAlreadyLinkedToBarredPlayer',
  [ALERT_CANNOT_CHANGE_FLAGGED_PLAYER_LINKED_GCM_PLAYER]: 'message.alertFlaggedPlayerAlreadyLinked',
  [ALERT_CANNOT_CHANGE_BARRED_PLAYER_LINKED_GCM_PLAYER]: 'message.alertBarredPlayerAlreadyLinked',
};

export const needShowErrorDialogCodes = [
  UNHANDLED_SYSTEM_EXCEPTION,
  CANNOT_OPERATE_DELETED_OR_HISTORY_BANNED_PLAYER,
  CANNOT_OPERATE_DELETED_OR_HISTORY_FLAGGED_PLAYER,
  GCM_PLAYER_CANNOT_BE_UNLINKED,
  GCM_PLAYER_CANNOT_BE_RELINKED,
  INVALID_PARAMS
];

export function getErrorMessage(error) {
  if (error.error && error.error.errorCode && error.error.errorCode === UNHANDLED_SYSTEM_EXCEPTION) {
    return '';
  }

  return (error.error && error.error.errorCode && ErrorMessage[error.error.errorCode]) || 'message.defaultMessage';
}

export function getErrorMessageByErrorCode(errorCode) {
  return ErrorMessage[errorCode] || 'message.defaultMessage';
}

export const loginErrorCodes = [
  INVALID_DIRECTORYSERVICE_INVALID_EMPLOYEE,
  INVALID_DIRECTORYSERVICE_INVALID_PASSWORD,
  INVALID_DIRECTORYSERVICE_ACCOUNT_LOCKED,
  INVALID_DIRECTORYSERVICE_PASSWORD_EXPIRED,
  INVALID_DIRECTORYSERVICE_ACCOUNT_DISABLED,
  NO_PERMISSION_TO_LOGIN,
];
