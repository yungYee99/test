import * as Moment from 'moment';

export function sortByKey(array, key) {
  const _array = array;
  return _array.sort(function (a, b) {
    if (key.indexOf('Date') > -1) {
      return getTimeStamp(a[key]) >= getTimeStamp(b[key]) ? -1 : 1;
    }
    if (typeof(a[key]) === 'string') {
      return a[key].toLowerCase() >= b[key].toLowerCase() ? -1 : 1;
    }
    return a[key] >= b[key] ? -1 : 1;
  });
}

export function getTimeStamp(date) {
  return Moment(Moment(date, 'DD-MMM-YYYY hh:mm A').format('YYYY-MM-DD HH:mm')).valueOf();
}
