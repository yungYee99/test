import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  isLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  isFold: BehaviorSubject<boolean> = new BehaviorSubject(true);
  hasApiError: BehaviorSubject<boolean> = new BehaviorSubject(false);
  errorCode: BehaviorSubject<string> = new BehaviorSubject('');
  alertCount: BehaviorSubject<number> = new BehaviorSubject(0);
  getAlertMessage: BehaviorSubject<any> = new BehaviorSubject(null);
  noLoading: BehaviorSubject<boolean> = new BehaviorSubject(false);
  cityOptions: BehaviorSubject<any> = new BehaviorSubject(null);
  identificationOptions: BehaviorSubject<any> = new BehaviorSubject(null);
  bannedReasonOptionList: BehaviorSubject<any> = new BehaviorSubject(null);

  refreshPage: any = '';
  state: any = {};

  constructor() {}

}
