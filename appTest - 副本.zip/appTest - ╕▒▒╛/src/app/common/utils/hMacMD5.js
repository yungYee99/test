const crypto = require('crypto')

function encodeMac (data, key) {
  if (!(data && key)) {
    return false
  }

  key = Buffer.from(key)
  data = Buffer.from(data)
  let reqhash = getHmacMd5Bytes(key, data)
  reqhash = encodeURIComponent(reqhash.toString('base64'))
  return reqhash
}

function md5 (str) {
  let md5 = crypto.createHash('md5')
  md5.update(str)

  return md5.digest()
}

function getHmacMd5Bytes (key, data) {
  if (!(data && key)) {
    return false
  }

  let length = 64
  let ipad = Buffer.alloc(length)
  let opad = Buffer.alloc(length)

  for (let i = 0; i < length; i++) {
    ipad[i] = 0x36
    opad[i] = 0x5C
  }

  let actualKey = key
  let keyArr = Buffer.alloc(length)

  if (key.length > length) {
    actualKey = md5(key)
  }

  for (let i = 0; i < actualKey.length; i++) {
    keyArr[i] = actualKey[i]
  }

  if (actualKey.length < length) {
    for (let i = actualKey.length; i < keyArr.length; i++) {
      keyArr[i] = 0x00
    }
  }

  let kIpadXorResult = Buffer.alloc(length)
  for (let i = 0; i < length; i++) {
    kIpadXorResult[i] = (keyArr[i] ^ ipad[i])
  }

  let firstAppendResult = Buffer.alloc(kIpadXorResult.length + data.length)
  for (let i = 0; i < kIpadXorResult.length; i++) {
    firstAppendResult[i] = kIpadXorResult[i]
  }

  for (let i = 0; i < data.length; i++) {
    firstAppendResult[i + keyArr.length] = data[i]
  }

  let firstHashResult = md5(firstAppendResult)
  let kOpadXorResult = Buffer.alloc(length)
  for (let i = 0; i < length; i++) {
    kOpadXorResult[i] = (keyArr[i] ^ opad[i])
  }

  let secondAppendResult = Buffer.alloc(kOpadXorResult.length + firstHashResult.length)
  for (let i = 0; i < kOpadXorResult.length; i++) {
    secondAppendResult[i] = kOpadXorResult[i]
  }

  for (let i = 0; i < firstHashResult.length; i++) {
    secondAppendResult[i + keyArr.length] = firstHashResult[i]
  }

  let hmacMd5Bytes = Buffer.from(md5(secondAppendResult))
  return hmacMd5Bytes
}

exports.encodeMac = encodeMac
