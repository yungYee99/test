const log4js = require('log4js')
var logConfig = require('../config/log_config')

// 加载配置文件
log4js.configure(logConfig)

var logger = log4js.getLogger('logger')

/**
 * Log Error message
 * - message，string类型的错误信息
 * - err, Error Object 对象
 * @param {*String} message
 * @param {*Object} err
 */
async function logMessageAndError (message, err) {
  try {
    var logText = ''
    // 错误信息开始
    logText += '\n' + '*************** error log start ***************' + '\n'
    // 添加请求日志
    logText += message
  
    if (err) {
      // 错误名称
      logText += 'err name: ' + err.name + '\n'
      // 错误信息
      logText += 'err message: ' + err.message + '\n'
      // 错误详情
      logText += 'err stack: ' + err.stack + '\n'
    }
  
    // 错误信息结束
    logText += '*************** error log end ***************' + '\n'
    logger.error(logText)
  } catch (err) {
    console.log(err);
  }
}

/**
 * Log message
 * - message，string类型的信息
 * @param {*String} message
 */
async function logMessage (message) {
  try {
    if (!message) {
      return
    }

    var logText = ''
    logText += '\n' + '*************** Information log start ***************' + '\n'
    logText += message + '\n'
    logText += '*************** Information log end ***************' + '\n'
    logger.info(logText)
  } catch (err) {
    console.log(err)
  }
}

/**
 * Log Error
 * - err, Error Object 对象
 * @param {*Object} err
 */
async function logError (err) {
  try {
    var logText = ''
    // 错误信息开始
    logText += '\n' + '*************** error log start ***************' + '\n'
  
    if (err) {
      // 错误名称
      logText += 'err name: ' + err.name + '\n'
      // 错误信息
      logText += 'err message: ' + err.message + '\n'
      // 错误详情
      logText += 'err stack: ' + err.stack + '\n'
    }
  
    // 错误信息结束
    logText += '*************** error log end ***************' + '\n'
    logger.error(logText)
  } catch (err) {
    console.log(err);
  }
}

exports.logMessageAndError = logMessageAndError
exports.logError = logError
exports.logMessage = logMessage
