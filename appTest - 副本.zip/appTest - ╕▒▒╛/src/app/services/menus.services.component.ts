import { Injectable } from '@angular/core';
import { MENUS } from '../services/menus-mock';

@Injectable()
export class MenusService {
getMenu(): Promise<any[]> {
return Promise.resolve(MENUS);
}
}
