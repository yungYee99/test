const HtmlWebPackPlugin = require('html-webpack-plugin');
const path = require('path');
const PrerenderSPAPlugin = require('prerender-spa-plugin');
const Renderer = PrerenderSPAPlugin.PuppeteerRenderer;
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

module.exports = {
  entry: ['@babel/polyfill', './src/main.jsx'],
  output: {
    chunkFilename: '[name].chunk.js'
  },
  module: {
    rules: [
      {
        test: /\.(jsx|js)$/,
        exclude: /node_modules/,
        use: ['babel-loader', 'eslint-loader']
      },
      {
        test: /\.html$/,
        use: {
          loader: 'html-loader',
          options: {
            minimize: true
          }
        }
      }
    ]
  },
  plugins: [
    new HtmlWebPackPlugin({
      template: 'public/index.html'
    }),
    new PrerenderSPAPlugin({
      // Index.html is in the root directory.
      staticDir: path.join(__dirname, '.', 'dist'),
      routes: ['/'],
      // Optional minification.
      minify: {
        collapseBooleanAttributes: true,
        collapseWhitespace: true,
        decodeEntities: true,
        keepClosingSlash: true,
        sortAttributes: true
      },

      renderer: new Renderer({
        renderAfterTime: 500
      })
    })
    // new BundleAnalyzerPlugin()
  ],
  resolve: {
    extensions: ['.js', '.jsx', '.scss', '.json', '.css'],
    alias: {
      '@pages': path.resolve(__dirname, './src/pages'),
      '@components': path.resolve(__dirname, './src/components'),
      '@actions': path.resolve(__dirname, './src/redux/actions'),
      '@actionTypes': path.resolve(__dirname, './src/redux/actionTypes.js'),
      '@reducers': path.resolve(__dirname, './src/redux/reducers')
    }
  },
  optimization: {
    splitChunks: {
      chunks: 'all'
    }
  },
  devServer: {
    // 错误的时候全局覆盖
    overlay: {
      errors: true
    },
    // shell 只输出错误
    stats: 'errors-only',
    // gzip
    compress: true
    // 代理
    // proxy: {
    //   "/api": "http://localhost:30001"
    // }
  }
};
