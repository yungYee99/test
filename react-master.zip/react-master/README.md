#### 从零搭建 react

> - react16.7
> - webpack4
> - babel7
> - redux

#### 基本目录

```
.
├── .babelrc // babel配置文件
├── .editorconfig // 编辑器的配置文件
├── .eslintignore // eslint 忽略文件
├── .eslintrc // eslint 配置
├── .gitignore // git 提交忽略文教
├── .prettierrc // prettier 统一风格美华
├── README.md // 描述
├── package.json // 依赖配置文件
├── public // 公共的文件
│   └── index.html
├── src // react代码文件夹
│   ├── components // 组件
│   ├── route // 路由
│   ├── pages // 页面
│   ├── redux // 状态管理
│   └── main.jsx // 启动页面
└── webpack.config.js // webpack 配置文件
```

#### webpack 构建的 js 引入到 html 中

> - 使用 `html-webpack-plugin`

```js
const HtmlWebPackPlugin = require('html-webpack-plugin');
plugins: [
  new HtmlWebPackPlugin({
    template: 'public/index.html'
  })
];
```

#### 压缩 html

> - 使用 `html-loader`

```js
rules: [
  {
    test: /\.html$/,
    use: {
      loader: 'html-loader',
      options: {
        minimize: true
      }
    }
  }
];
```

#### react 的 jsx 代码 和 eslint 使用 `babel-loader && eslint-loader`

```js
rules: [
  {
    test: /\.(jsx|js)$/,
    exclude: /node_modules/,
    use: ['babel-loader', 'eslint-loader']
  }
];
```

#### es6 react 预设集成了很多新特性和新语法的 按需转换 使用 `@babel/preset-env && @babel/preset-react`

```json
{
  "presets": ["@babel/preset-env", "@babel/preset-react"]
}
```

#### 编辑器的规则 `.editorconfig` 文件存在的话会优先使用这个配置

```
root = true

[*]
charset = utf-8
indent_style = space
indent_size = 2
end_of_line = lf
insert_final_newline = true
trim_trailing_whitespace = true

```

#### 文件路径的快捷 使用

```
resolve: {
  alias: {
    '@pages': path.resolve(__dirname, './src/pages')
  }
}
```

#### 装饰器写法 使用 `@babel/plugin-proposal-decorators`

```
"plugins": [
  [
    "@babel/plugin-proposal-decorators",
    {
      "decoratorsBeforeExport": true
    }
  ]
]
```

#### 文件内引入不需要后缀的配置

```js
resolve: {
  extensions: ['.js', '.jsx', '.ts', '.tsx', '.scss', '.json', '.css'],
}
```

#### webpack 配置 chunkname

```
output:{
    chunkFilename: "[name].chunk.js"
}
```

#### 路由封装鉴权实现

```js
import React from 'react';
import login from '@unstated/login';
import { Subscribe } from 'unstated';
import { HashRouter, Route, Switch, Redirect } from 'react-router-dom';
import Routers from './router.config';

const App = () => (
  <Subscribe to={[login]}>
    {object => (
      <HashRouter>
        <Switch>
          {Routers.map(item => {
            return (
              <Route
                exact
                key={item.name}
                path={item.path}
                render={props => RenderComponent(props, item, object.state.token)}
              />
            );
          })}
        </Switch>
      </HashRouter>
    )}
  </Subscribe>
);
const RenderComponent = (props, item, token) =>
  !item.auth ? (
    <item.component {...props} />
  ) : token ? (
    <item.component {...props} />
  ) : (
    <Redirect
      to={{
        pathname: '/',
        state: { from: props.location }
      }}
    />
  );
export default App;
```

#### 状态管理 使用`unstated` 要使用`@babel/plugin-proposal-class-properties`

```json
 "plugins": [
    "@babel/plugin-proposal-class-properties",
 ]
```

#### 首屏预渲染 `prerender-spa-plugin`

```js
const PrerenderSPAPlugin = require('prerender-spa-plugin');
const Renderer = PrerenderSPAPlugin.PuppeteerRenderer;
plugins: [
  new PrerenderSPAPlugin({
    // Index.html is in the root directory.
    staticDir: path.join(__dirname, '.', 'dist'),
    routes: ['/'],
    // Optional minification.
    minify: {
      collapseBooleanAttributes: true,
      collapseWhitespace: true,
      decodeEntities: true,
      keepClosingSlash: true,
      sortAttributes: true
    },

    renderer: new Renderer({
      renderAfterTime: 500
    })
  })
];
```

#### 组件和路由懒加载都可使用 `loadable-components` 打包的时候会将代码切割

```js
import lazy from 'loadable-components';

export const Home = lazy(() => import(/* webpackChunkName: 'pages-home'*/ '@pages/home'));

export const Test = lazy(() => import(/* webpackChunkName: 'pages-test'*/ '@pages/test'));
```

#### 使用 async await `@babel/plugin-transform-async-to-generator`

```js
  // .babelrc
  "plugins": [
    "@babel/plugin-transform-async-to-generator"
  ],
  async login({ history }) {
    const response = await list();
    const { code } = response.data;
    if (code === 1) {
      await this.setState({
        token: true
      });
      history.push('/abc');
    }
  }
```

#### 报 regeneratorRuntime is not defined 错误 需使用`@babel/polyfill`

```js
  entry: ['@babel/polyfill', './src/main.jsx'],
```

#### hot 热重载 `--hot --inline`

```js
// packjson 加入 --hot --inline hot失败会刷新页面
// main.js 加入
if (module.hot) {
  module.hot.accept();
}
```

#### css 方案选择 `styled-components`

```js
// 支持嵌套 响应式 做css 动画很方便 可以接收state
import styled from 'styled-components';

const Title = styled.div`
  color: #ccc;
  & > span {
    color: red;
  }
`;
```

#### git 提交的方案 使用`cz-conventional-changelog`

```json
  "config": {
    "commitizen": {
      "path": "./node_modules/cz-conventional-changelog"
    }
  }
```

#### http 请求鉴权 jsonwebtoken 方案

```js
import axios from 'axios';
const http = axios.create({
  baseURL: 'https://www.lvsebeiying.cn',
  headers: {
    Authorization: 'token',
    'Content-Type': 'application/json;charset=UTF-8'
  },
  timeout: 1000
});

// 添加请求拦截器
http.interceptors.request.use(
  config => {
    // 在发送请求之前做些什么 比如：
    config['headers']['Authorization'] = 'token.abc';
    return config;
  },
  error => {
    // 对请求错误做些什么
    return Promise.reject(error);
  }
);

// 添加响应拦截器
http.interceptors.response.use(
  response => {
    // 对响应数据做点什么
    return response;
  },
  error => {
    // 对响应错误做点什么 ：比如
    error.response.status === 401 && alert('token 失效');
    return Promise.reject(error);
  }
);

export default http;
```

#### api 请求模块化 方便管理

```js
import http from './index';

export const list = () => http.get('/api/list');
```

#### 在非组件下使用 react-router-dom 的方法

```js
import createHistory from 'history/createBrowserHistory';
const history = createHistory();

/* console.log
action: "POP"
block: ƒ block()
createHref: ƒ createHref(location)
go: ƒ go(n)
goBack: ƒ goBack()
goForward: ƒ goForward()
length: 20
listen: ƒ listen(listener)
location: {pathname: "/", search: "", hash: "#/", state: undefined}
push: ƒ push(path, state)
replace: ƒ replace(path, state)
*/
```

#### 使用 react 自带的 lazy

```js
// 要有Suspense组件的 fallback = { loading }
import { lazy } from 'react';
export const Home = lazy(() => import(/* webpackChunkName: 'pages-home'*/ '@pages/home'));

export const Test = lazy(() => import(/* webpackChunkName: 'pages-test'*/ '@pages/test'));
```

#### useEffect 直接`async`使用会报 warning 问题 使用下面方法

```js
useEffect(() => {
  (async () => {
    try {
      const response = await fetch('https://www.lvsebeiying.cn/api/list');
      const json = await response.json();
      const data = json.list.reverse();
      setList(data);
    } catch (error) {
      console.log(error);
    }
  })();
}, []);
```

#### webpack 构建后分析 webpack 打包的各文件的大小 `webpack-bundle-analyzer`

```js
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer'.BundleAnalyzerPlugin;
plugin:[
  new BundleAnalyzerPlugin()
]
```

#### webpack 的`webpack --mode=production` `webpack --mode=development`

```js
// 可以在需要不同环境的使用 这个变量
console.log(process.env.NODE_ENV);
```

#### 将第三方依赖的 node_modules 代码拆分开来

```js
optimization: {
  splitChunks: {
    chunks: 'all'
  }
},
/*
  <script src="vendors~main.chunk.js" type="text/javascript"></script>
  <script src="main.js" type="text/javascript"></script>
*/
```

#### 使用 github pages

```
yarn add gh-pages --dev

package.json 加入 自己的 githubpage 地址 :

"homepage":"http://linronglang.github.io/react"

"build": "rm -rf dist && webpack --mode=production",

"predeploy": "yarn build",

"deploy": "gh-pages -d dist"

使用 yarn deploy 会运行打包 后将打包的文件 会上传至github分支
```

#### redux 页面组件 connect 连接使用

```js
import React from 'react';
import { connect } from 'react-redux';
import { setLogin } from '../redux/actions/login';

const App = ({ isLogin, setLogin }) => {
  return (
    <div>
      <p>{isLogin ? '登陆' : '未登录'}</p>
      <button onClick={setLogin}>click</button>
    </div>
  );
};

export default connect(
  state => state['login'],
  { setLogin }
)(App);
```

#### redux-thunk 异步 action

```js
// 调试工具包裹的中间件使用
import thunk from 'redux-thunk';
const store = createStore(
  combineReducers({
    login
  }),
  composeWithDevTools(applyMiddleware(thunk))
);
```

#### 异步 action

> - action 必须是普通对象 加入中间件可以返回一个异步函数
> - 异步函数 结果在调用正式改变的 action 进入 reducer

```js
import { LOGIN } from '@actionTypes';

const setLoginState = json => {
  return {
    type: LOGIN,
    json
  };
};

export const setLogin = () => {
  return async dispatch => {
    try {
      const response = await fetch('https://www.lvsebeiying.cn/api/list');
      const json = await response.json();
      dispatch(setLoginState(json));
    } catch (error) {
      console.log(error);
    }
  };
};
```
