import React, { useState } from 'react';
import styled from 'styled-components';

const flex = {
  flex_container: {
    display: 'flex',
    props: ['flexDirection', 'flexWrap', 'justifyContent', 'alignItems', 'alignContent'],
    value: [
      ['row', 'row-reverse', 'column', 'column-reverse'],
      ['nowrap', 'wrap', 'wrap-reverse'],
      ['flex-start', 'flex-end', 'center', 'space-between', 'space-around'],
      ['flex-start', 'flex-end', 'center', 'baseline', 'stretch'],
      ['flex-start', 'flex-end', 'center', 'space-between', 'space-around', 'stretch']
    ]
  },
  flex_childer: {
    order: 0,
    'flex-grow': 0,
    'flex-shrink': 1,
    'align-self': ['auto', 'flex-start', 'flex-end', 'center', 'baseline', 'stretch']
  }
};

export default () => {
  const [width, setWidth] = useState('100');
  const [height, setHeight] = useState('100');
  const [color, setColor] = useState('');
  const [divState, setDiv] = useState([]);
  const [flexState, setFlex] = useState([]);
  const flexKey = () => {
    return flex.flex_container.props.map((item, index) => {
      return (
        <div
          key={index}
          style={{
            margin: '5px',
            borderBottom: '1px solid #ccc',
            padding: '5px 0',
            display: 'flex',
            justifyContent: 'space-between'
          }}
        >
          <span>{item}</span>
          <select
            onBlur={e => {
              setFlex({
                ...flexState,
                [item]: e.target.value
              });
              console.log(e.target.value);
            }}
          >
            {flex.flex_container.value[index].map(item => {
              return (
                <option key={item} value={item}>
                  {item}
                </option>
              );
            })}
          </select>
        </div>
      );
    });
  };
  const clickChilder = i => {
    const data = divState.map((item, index) => {
      if (i === index) {
        return {
          ...item,
          border: '1px solid red'
        };
      } else {
        return {
          ...item,
          border: 'none'
        };
      }
    });
    setDiv(data);
  };
  return (
    <FlexContainer>
      <FlexContainerLeftBox style={flexState}>
        {divState.map((item, index) => {
          return (
            <div
              onClick={() => clickChilder(index)}
              role="button"
              tabIndex={index}
              key={index}
              style={{
                width: item.width,
                height: item.height,
                background: item.color
              }}
            />
          );
        })}
      </FlexContainerLeftBox>
      <FlexContainerRightBox>
        <InputColor>
          <span>增加div:</span>
          <label htmlFor="width">
            width:
            <input
              type="number"
              id="width"
              name="width"
              value="100"
              onChange={e => setWidth(e.target.value)}
            />
          </label>
          <label htmlFor="height">
            height:
            <input
              type="number"
              id="height"
              value="100"
              name="height"
              onChange={e => setHeight(e.target.value)}
            />
          </label>
          <label htmlFor="color">
            color:
            <input type="color" id="color" name="color" onChange={e => setColor(e.target.value)} />
          </label>
          <button
            onClick={e => {
              e.preventDefault();
              if (!width) alert('请输入width');
              if (!height) alert('请输入height');
              if (!color) alert('请输入color');
              if (width && height && color) {
                const data = [
                  ...divState,
                  {
                    width: width + 'px',
                    height: height + 'px',
                    color
                  }
                ];
                setDiv(data);
              }
            }}
          >
            生成
          </button>
        </InputColor>
        <ContainerBox>
          <label
            htmlFor="flex"
            style={{
              margin: '5px 0',
              borderBottom: '1px solid #ccc',
              display: 'block',
              padding: '5px 0'
            }}
          >
            <input
              type="checkbox"
              id="flex"
              onChange={e => {
                if (e.target.checked) {
                  setFlex({
                    ...flexState,
                    display: 'flex'
                  });
                } else {
                  setFlex({
                    ...flexState,
                    display: ''
                  });
                }
              }}
            />
            display: flex;
          </label>
          <h4>容器属性：失去焦点生效</h4>
          {flexKey()}
          <h4>元素属性：</h4>
        </ContainerBox>
      </FlexContainerRightBox>
    </FlexContainer>
  );
};

const FlexContainer = styled.div`
  width: 1000px;
  height: 600px;
  /* box-sizing: border-box; */
  display: flex;
  position: fixed;
  margin: auto;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  &::before {
    content: 'Flex 弹性盒模型';
    position: absolute;
    font-size: 25px;
    top: -50px;
    width: inherit;
    text-align: center;
    font-weight: bold;
    color: #555;
  }
`;
const FlexContainerLeftBox = styled.div`
  width: 600px;
  height: 600px;
  border: 1px solid #ccc;
  box-sizing: border-box;
  &::after {
    content: '300px';
    position: absolute;
    left: -325px;
    top: 0;
    bottom: 0;
    transform: rotateZ(90deg);
    color: #555;
  }
  &::before {
    content: '300px';
    position: absolute;
    top: -22px;
    width: inherit;
    text-align: center;
    color: #555;
  }
`;
const FlexContainerRightBox = styled.div`
  width: 390px;
  height: 600px;
  box-sizing: border-box;
  border: 1px solid #ccc;
  font-size: 12px;
  margin-left: 10px;
  user-select: none;
`;
const InputColor = styled.form`
  margin: 5px;
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid #ccc;
  align-items: center;
  padding: 5px 0;
  & input {
    width: 40px;
  }
`;
const ContainerBox = styled.div`
  margin: 5px;
`;
