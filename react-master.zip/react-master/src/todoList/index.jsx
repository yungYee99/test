import React from 'react';
import { connect } from 'react-redux';
import { setLogin } from '@actions/login';

const App = ({ isLogin, setLogin }) => {
  return (
    <div>
      <p>{isLogin ? '登陆' : '未登录'}</p>
      <button onClick={() => setLogin()}>click</button>
    </div>
  );
};

export default connect(
  state => state['login'],
  { setLogin }
)(App);
