import React, { useEffect, useState } from 'react';

export default props => {
  const [content, setContent] = useState({});
  useEffect(() => {
    (async () => {
      const response = await fetch(
        `https://www.lvsebeiying.cn/api/content/${props.match.params.id}`
      );
      const json = await response.json();
      setContent(json.result[0]);
    })();
  }, []);
  return (
    <div>
      <h3>{content.title}</h3>
      <p style={{ fontSize: '14px', color: '#ccc' }}>
        <span>时间：{new Date(content.time).toLocaleDateString()}</span>
        <span style={{ marginLeft: '15px' }}>浏览：{content.look}</span>
      </p>
      <div dangerouslySetInnerHTML={{ __html: content.content }} />
    </div>
  );
};
