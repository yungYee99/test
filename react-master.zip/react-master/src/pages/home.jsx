import React, { useEffect, useState } from 'react';
export default props => {
  const [list, setList] = useState([]);
  useEffect(() => {
    (async () => {
      try {
        const response = await fetch('https://www.lvsebeiying.cn/api/list');
        const json = await response.json();
        const data = json.list.reverse();
        setList(data);
      } catch (error) {
        console.log(error);
      }
    })();
  }, []);
  const jumpContent = (id, look, props) => {
    fetch(`https://www.lvsebeiying.cn/api/look/${id}/${look}`, {
      method: 'put',
      mode: 'cors'
    });
    props.history.push('/' + id);
  };

  return (
    <ul>
      {list.map(item => {
        return (
          <li
            onClick={() => jumpContent(item._id, item.look, props)}
            key={item._id}
            style={{ borderBottom: '1px solid #ccc', cursor: 'pointer' }}
          >
            <p>{item.title}</p>
            <p style={{ fontSize: '14px', color: '#ccc' }}>
              <span>时间：{new Date(item.time).toLocaleDateString()}</span>
              <span style={{ marginLeft: '15px' }}>浏览：{item.look}</span>
            </p>
          </li>
        );
      })}
    </ul>
  );
};
