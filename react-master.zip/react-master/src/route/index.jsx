import React from 'react';
import { HashRouter, Route, Switch } from 'react-router-dom';
import routers from './router.config';

export default () => (
  <HashRouter>
    <Switch>
      {routers.map(item => {
        return (
          <Route
            exact
            key={item.name}
            path={item.path}
            render={props => <item.component {...props} />}
          />
        );
      })}
    </Switch>
  </HashRouter>
);
