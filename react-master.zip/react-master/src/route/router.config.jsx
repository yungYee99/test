import { lazy } from 'react';

const Home = lazy(() => import(/* webpackChunkName: 'pages-home'*/ '@pages/home'));
const Content = lazy(() => import(/* webpackChunkName: 'pages-test'*/ '@pages/content'));

export default [
  {
    path: '/',
    name: 'home',
    component: Home
  },
  {
    path: '/:id',
    name: 'content',
    component: Content
  }
];
