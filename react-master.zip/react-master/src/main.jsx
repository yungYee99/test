import React, { Suspense } from 'react';
import ReactDom from 'react-dom';

import { Provider } from 'react-redux';
import store from './redux';

// const App = lazy(() => import(/* webpackChunkName: 'App' */ './route'));
// import App from './todoList';
import App from './components/flex';

ReactDom.render(
  <Suspense fallback={null}>
    <Provider store={store}>
      <App />
    </Provider>
  </Suspense>,
  document.getElementById('root')
);

if (module.hot) {
  module.hot.accept();
}
