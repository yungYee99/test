import { LOGIN } from '@actionTypes';

const setLoginState = json => {
  return {
    type: LOGIN,
    json
  };
};

export const setLogin = () => {
  return async dispatch => {
    try {
      const response = await fetch('https://www.lvsebeiying.cn/api/list');
      const json = await response.json();
      dispatch(setLoginState(json));
    } catch (error) {
      console.log(error);
    }
  };
};
