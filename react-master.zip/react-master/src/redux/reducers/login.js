const login = {
  isLogin: false
};

export default (state = login, action) => {
  switch (action.type) {
    case 'LOGIN':
      return { ...state, isLogin: action.json };
    default:
      return state;
  }
};
